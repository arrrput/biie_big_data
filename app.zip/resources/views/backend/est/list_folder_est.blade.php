@extends('layouts.backend')

@section('title')
    Estate || Big Data
@endsection

@section('content')

    {{ $param }}
@endsection