
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 0.1
    </div>
    <strong>Copyright &copy; 2022 <a href="https://bintanindustrial.com">BIIE</a>.</strong> All rights reserved.
  </footer>
