<!-- Google Font: Source Sans Pro -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,400;0,500;0,700;0,800;1,200;1,300;1,500&display=swap" rel="stylesheet">
<!-- Font Awesome -->
<link rel="stylesheet" href="{{ URL::asset('plugins/fontawesome-free/css/all.min.css') }}">
<!-- Theme style -->
<link rel="stylesheet" href="{{ URL::asset('dist/css/adminlte.min.css') }}">
{{-- datatables --}}
<link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="{{ URL::asset('plugins/chart.js/Chart.css') }}">
<link rel="stylesheet" href="{{ URL::asset('plugins/chart.js/Chart.min.css') }}">
