<h3>Halo, {{ $nama }} !</h3>
<p>{{ $website }}</p>
 
<p>Selamat datang di <a href="#">www.bintanindestrial.com</a></p>
